﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GifSearch.Models
{
    public class Images
    {
      public  Fixed_Height  fixed_height  { get; set; }
    }
}
