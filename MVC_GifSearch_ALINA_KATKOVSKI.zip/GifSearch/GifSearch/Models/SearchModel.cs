﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GifSearch.Models
{
    public class SearchModel
    {

        [BindRequired ]
        public string SearchTxt { get; set; }

        public List<Data> data { get; set; }

    }
}
