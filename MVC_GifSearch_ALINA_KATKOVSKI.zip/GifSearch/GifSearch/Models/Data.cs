﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GifSearch.Models
{
    public class Data
    {
        public string bitly_gif_url { get; set; }
        public string title { get; set; }
        public Images images { get; set; }

    }
}
