﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GifSearch.Models
{
    public class Fixed_Height
    {
        public string  url { get; set; }
    }
}
