﻿using GifSearch.Helpers;
using GifSearch.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics; 

namespace GifSearch.Controllers
{
    public class GiphyController : Controller
    {
        private readonly IMemoryCache _cache;

        private readonly ILogger<GiphyController> _logger;
        private GifHelper _gifHelper;
        public GiphyController(ILogger<GiphyController> logger, IMemoryCache memoryCache)
        {
            _logger = logger;
            _gifHelper = new GifHelper();
            _cache = memoryCache;
        }
        public IActionResult Index()
        {
            return View();
        }
         
        [HttpPost]
         
        public ActionResult Search(SearchModel model)
        {
            if (ModelState.IsValid)
            {
                string search = model.SearchTxt;
                if (!_cache.TryGetValue<SearchModel>(search, out model))
                {
                    
                    model = _gifHelper.SearchGif(search).Result;
                   
                    _cache.Set<SearchModel>(search, model);
                }
                 
                ViewBag.urls = model.data;
                ModelState.Clear(); 
                return View(model);
            }
            else
            {
                return RedirectToAction("Error");
            }
        }
        public IActionResult Search()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Trending(TrendingModel model)
        {

            model = _gifHelper.ViewTrending().Result;
            ViewBag.urls = model.data;
            ModelState.Clear();
            return View(model);
        } 
        public IActionResult Trending()
        {
            return View();
        }
       

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
