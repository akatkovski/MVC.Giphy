﻿using GifSearch.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace GifSearch.Helpers
{
    public class GifHelper
    {

        const string _apiKey = "EQzVDOYwTdV7yQrEzLyuGzaDjw9oaRPT";
        public async Task<SearchModel> SearchGif(string searchTxt)
        {

            using (var client = new HttpClient())
            {
                var url = new Uri($"http://api.giphy.com/v1/gifs/search?api_key={_apiKey}&q={searchTxt}&limit=10");

                var response = await client.GetAsync(url);

                string json;
                using (var content = response.Content)
                {
                    json = await content.ReadAsStringAsync();
                }

                return JsonConvert.DeserializeObject<SearchModel>(json);
            }

        }

        public async Task<TrendingModel> ViewTrending( )
        {

            using (var client = new HttpClient())
            {
                var url = new Uri($"http://api.giphy.com/v1/gifs/trending?api_key={_apiKey}&limit=10");

                var response = await client.GetAsync(url);

                string json;
                using (var content = response.Content)
                {
                    json = await content.ReadAsStringAsync();
                }

                return JsonConvert.DeserializeObject<TrendingModel>(json);
            } 
        }

    }
 
}
